




document.getElementById("f3").onclick = function(){
	var f3_toets = document.getElementById("audio_f3");
	f3_toets.play();
}
document.getElementById("g3").onclick = function(){
	var g3_toets = document.getElementById("audio_g3");
	g3_toets.play();
}
document.getElementById("a4").onclick = function(){
	var a4_toets = document.getElementById("audio_a4");
	a4_toets.play();
}
document.getElementById("b4").onclick = function(){
	var b4_toets = document.getElementById("audio_b4");
	b4_toets.play();
}
document.getElementById("c4").onclick = function(){ 
	var c4_toets = document.getElementById("audio_c4");
	c4_toets.play(); 
}
document.getElementById("d4").onclick = function(){
	var d4_toets = document.getElementById("audio_d4");
	d4_toets.play();
}
document.getElementById("e4").onclick = function(){
	var e4_toets = document.getElementById("audio_e4");
	e4_toets.play();
}

document.getElementById("f4").onclick = function(){
	var f4_toets = document.getElementById("audio_f4");
	f4_toets.play();
}
document.getElementById("g4").onclick = function(){
	var g4_toets = document.getElementById("audio_g4");
	g4_toets.play();
}
document.getElementById("a5").onclick = function(){
	var a5_toets = document.getElementById("audio_a5");
	a5_toets.play();
}
document.getElementById("b5").onclick = function(){
	var b5_toets = document.getElementById("audio_b5");
	b5_toets.play();
}
document.getElementById("c5").onclick = function(){
	var c5_toets = document.getElementById("audio_c5");
	c5_toets.play();
}
document.getElementById("d5").onclick = function(){
	var d5_toets = document.getElementById("audio_d5");
	d5_toets.play();
}
document.getElementById("e5").onclick = function(){
	var e5_toets = document.getElementById("audio_e5");
	e5_toets.play();
}
document.getElementById("f5").onclick = function(){
	var f5_toets = document.getElementById("audio_f5");
	f5_toets.play();
}
document.getElementById("g5").onclick = function(){
	var g5_toets = document.getElementById("audio_g5");
	g5_toets.play();
}
